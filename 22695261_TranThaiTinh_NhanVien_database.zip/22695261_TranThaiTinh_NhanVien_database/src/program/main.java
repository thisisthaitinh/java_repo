package program;

import nhanVien.NhanVien_GUI;

public class main {
    public static void main(String[] args) {
    	new NhanVien_GUI();
    }
}

